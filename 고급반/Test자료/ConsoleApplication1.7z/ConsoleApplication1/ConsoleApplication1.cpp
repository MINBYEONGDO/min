﻿

#include "pch.h"
#include <iostream>
#include <string>
#include <time.h>
using namespace std;

int main()
{
	srand(time(NULL));
	int num1=0, num2=0;
	cout << "두수 입력" << endl;
	cin >> num1;
	cin >> num2;
	if (num1 > num2)
	{
		if (num1 % 2 == 0)
		{
			cout <<"큰 수는 "<< num1<< "입니다." << endl;
		}
		else
			cout << "짝수가 아닙니다." << endl;
	}
	else if (num2 > num1)
	{
		if (num2 % 2 == 0)
		{
			cout << "큰 수는 " << num2 << "입니다." << endl;
		}
		else
			cout << "짝수가 아닙니다." << endl;
	}
	system("pause");
	system("cls");
	int eng=0;
	int kor=0;
	int math=0;
	float avg=0;
	int sum=0;
	cout << "영어 점수 입력 :";
	cin >> eng;
	cout << "국어 점수 입력 :";
	cin >> kor;	
	cout << "수학 점수 입력 :";
	cin >> math;
	sum = eng + kor + math;
	avg = sum / 3;
	if (avg >= 90)
	{
		cout << "평균 학점 : A" << endl;
	}
	else if (avg >= 80)
	{
		cout << "평균 학점 : B "<< endl;
	}
	else if (avg >= 70)
	{
		cout << "평균 학점 : C " << endl;
	}
	else if (avg >= 60)
	{
		cout << "평균 학점 : D " << endl;
	}
	else
	{
		cout << "평균 학점 : F " << endl;
	}
	system("cls");
	int Sum=0;
	int num3=0;
	for (int i = 0; i <= 1000; i++)
	{
		if(i%3 !=0 || (i%3==0&&i%5==0))
		Sum += i;
	}
	cout << "1~1000까지 합계 : "<<Sum << endl;

	Sum = 0;
	num3 = 0;
	while (1)
	{
		cout << "정수를 입력하시오 :" ;
		cin >> num3;
		if (num3 == 0)
			break;
		else
			Sum += num3;
	}
	cout << "정수의 총합계" << Sum <<endl;
	system("cls");
	int num4;
	int rnum = rand() % 50;
	while (1)
	{
		system("cls");
		cout << "정수를 입력하시오(0입력시 종료됩니다.) : ";
		cin >> num4;
		if (num4 == rnum)
		{
			cout << "정답입니다." << endl;

			break;
		}
		else if (num4 > rnum)
			cout << num4 << "보다 작습니다." << endl;
		else if(num4 < rnum)
			cout << num4 << "보다 큽니다." << endl;
	}
}

